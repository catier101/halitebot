import hlt, logging
from hlt import NORTH, EAST, SOUTH, WEST, STILL, Move, Square
import random


myID, game_map = hlt.get_init()
hlt.send_init("MyPythonBot")


def target_enemy_production(square):
    direction = (None, None)
    current = square
    max_distance = min(game_map.width, game_map.height) / 5
    for square in game_map:
        if square.owner not in (0, myID):
            production_val = sum(neighbor.production for neighbor in game_map.neighbors(square))
            strength_val = sum(neighbor.production for neighbor in game_map.neighbors(square))
            if production_val > 10 and square.strength > strength_val :
                for d in (NORTH, EAST, SOUTH, WEST):
                    distance = 0

                    while current.owner == myID and distance < max_distance:
                        distance += 1
                        current = game_map.get_target(current, d)

                    if distance < max_distance:
                        direction = d
                        max_distance = direction

                    return direction
            else:
                direction = STILL
                return direction


def find_nearest_enemy_direction(square):
    direction = NORTH
    max_distance = min(game_map.width, game_map.height) / 2

    for d in (NORTH, EAST, SOUTH, WEST):
        distance = 0
        current = square

        while current.owner == myID and distance < max_distance :
            distance+= 1
            current = game_map.get_target(current, d)

        if distance < max_distance :
            direction = d
            max_distance = direction

    return direction

def heuristic(square):
    if square.owner == 0 :
        return (pow(square.production, 2) + 1) / (square.strength + 1)
    else :
        return sum(neighbor.strength for neighbor in game_map.neighbors(square) if neighbor.owner not in (0, myID))

def assign_move(square):
    enemy_border = any(neighbor.owner not in (0, myID) for neighbor in game_map.neighbors(square))
    target, direction = max(((neighbor, direction) for direction, neighbor in enumerate(game_map.neighbors(square))
                             if neighbor.owner != myID),
                            default=(None,None),
                            key=lambda t: heuristic(t[0]))
    if direction is not None and target.strength < square.strength:
        if enemy_border:
            direction = target_enemy_production(square)
            return Move(square,direction)
        elif direction is not None:
                return Move(square, direction)
    elif square.strength < square.production * 4:
        return Move(square,STILL)

    border = any(neighbor.owner != myID for neighbor in game_map.neighbors(square))
    if not border:


        direction = find_nearest_enemy_direction(square)
        if direction is not None:
            return Move(square, direction)

    else :
        return Move(square, STILL)



while True:
    game_map.get_frame()
    moves = [assign_move(square) for square in game_map if square.owner == myID]
    hlt.send_frame(moves)